# -*- coding: utf-8 -*-
"""
Created on Tue Jun 12 09:53:53 2018

@author: lenovo
使用说明
=====================================================================
一、功能说明
1、第一步：质量分析：统计原始变量的数据分布、缺失值、异常值情况，并对变量进行初步评分，评估变量优劣；
2、第二步：数据清洗：对质量太差的数据剔除后进行数据清洗，包括针对不同情境填充缺失值、删除重复值；
3、第三步：指标评分：数据清洗完成后进行指标综合评分，并结合总分进行特征选择，得到指标筛选情况表，内容包括是否保留或删除变量建议、变量总分、原因说明。
4、输出数据：提供两份数据，一份为对原始数据清洗完成后的数据，一份为清洗完成并只保留了优质变量的数据，用户可按自身需求来选择。
二、输入说明
需要用户输入的部分共三块：
1、输入数据名称：原始数据名称，例如 nx_jm.csv（注意：需带文件格式后缀）
2、输入存储路径：数据存储目录，例如：D:/data
3、输入目标变量名称：数据中的目标变量名称，若无目标变量，则直接回车跳过，例如：宽带办理类型（注意：不需加引号）
4、输入标识性变量：数据中标识性变量，例如：用户标识,序号（注意：多个变量需用英文逗号隔开，没有则直接回车跳过）
三、输出说明
1、数据质量分析文件：
1）con_result.csv：存储数值型变量统计分析情况；
2）type_result.csv：存储分类型变量统计分析情况。
2、指标筛选情况文件：
   v_selection.csv：存储指标筛选情况，共四列：
第一列变量名称；
第二列变量删除保留建议（其中"√"表示质量较好,"*"表示质量一般,"X"表示建议删除）；
第三列指标综合评分（分值范围：0-100）；
第四列删除保留变量原因说明。
3、两份数据：
1）d_clean.csv：数据清洗完成的数据；
2）d_clean_del.csv：清洗完成并只保留了优质变量的数据。


"""

import pandas as pd

#---数据质量
def ana_cont(df,out_method = "quantile"):
     import pandas as pd
     import numpy as np
     df = df.apply(lambda x: x.replace(' ', np.NaN))
     cont_features = df.columns[(df.dtypes == 'int64') | (df.dtypes == 'float64')]
     df = df[cont_features]
     res_df = pd.concat([df.apply(lambda x: x.dtype,axis = 0),df.apply(lambda x: x.count(),axis = 0),df.apply(lambda x: x.min(),axis = 0),
                    df.apply(lambda x: x.max(),axis = 0),df.apply(lambda x: round(x.mean(),2),axis = 0),df.apply(lambda x: round(x.mode()[0],2),axis = 0),
                    df.apply(lambda x: round(x.median(),2),axis = 0),df.apply(lambda x: round(x.std(),2),axis = 0),df.apply(lambda x: x.quantile(.25),axis = 0),
                    df.apply(lambda x: x.quantile(.5),axis = 0),df.apply(lambda x: x.quantile(.75),axis = 0),
                    df.apply(lambda x: sum(x.isnull())/len(x),axis = 0),df.apply(lambda x: sum(x.isnull()),axis = 0)],axis = 1)
     if(out_method == "std"):
        res_df = pd.concat([res_df,df.apply(lambda x: sum((x < (np.mean(x) - 3*np.std(x))) | (x > (np.mean(x) + 3*np.std(x)))),axis =0),df.apply(lambda x: np.mean(x[x < (np.mean(x) - 3*np.std(x))]),axis =0),df.apply(lambda x: np.mean(x[x > (np.mean(x) + 3*np.std(x))]),axis =0)],axis = 1)
     if(out_method == "quantile"):
        res_df = pd.concat([res_df,df.apply(lambda x: sum((x < x.quantile(0.001)) | (x > x.quantile(0.999))),axis =0),df.apply(lambda x: np.mean(x[x < x.quantile(0.001)]),axis =0),df.apply(lambda x: np.mean(x[x > x.quantile(0.999)]),axis =0)],axis = 1)
     if(out_method == "box"):
        res_df = pd.concat([res_df,df.apply(lambda x: sum((x < (x.quantile(0.25) - 1.5*(x.quantile(0.75) - x.quantile(0.25)))) | (x > (x.quantile(0.75) + 1.5*(x.quantile(0.75) - x.quantile(0.25))))),axis =0),df.apply(lambda x: np.mean(x[x < (x.quantile(0.25) - 1.5*(x.quantile(0.75) - x.quantile(0.25)))]),axis =0),df.apply(lambda x: np.mean(x[x > (x.quantile(0.75) + 1.5*(x.quantile(0.75) - x.quantile(0.25)))]),axis =0)],axis = 1)
     res_df.columns = ['数据类型','统计个数','最小值','最大值','均值','众数','中位数','标准差','四分之一位点','二分之一位点','四分之三位点','缺失值占比','缺失值个数','异常值个数','低异常值均值','高异常值均值']
     return res_df.T.to_csv("con_result.csv", encoding='utf_8_sig')

def ana_type(x):
     import pandas as pd
     import numpy as np
     x = x.apply(lambda x: x.replace(' ', np.NaN))
     res_df=pd.DataFrame()
     type_featrues = x.columns[x.dtypes == 'object']
     x=x[type_featrues]
     x = x.fillna("missing")
     for j in range(x.columns.size):
        temp=x.iloc[:,j]
        temp=temp.value_counts(dropna=False).reset_index()
        temp=temp.rename(columns={'index':'包含类别'})
        res_df=pd.concat([res_df, temp], axis=1, join='outer')
     j=j+1
     return pd.concat([res_df.head(100),res_df.tail(10)]).to_csv("type_result.csv", encoding='utf_8_sig')

#--指标评价（初步筛选）
#label_colname默认为空     
def v_judge(df,label_colname):
    import pandas as pd
    import numpy  as np 
    import sklearn
    from sklearn import preprocessing  
    v = pd.DataFrame(df.apply(lambda x: sum(x.isnull())/len(x),axis = 0))
    v.columns = ['na_per']
    v['score1']  = v['na_per'].apply(lambda x: np.exp(-x) if x < 0.8 else 0) 
    v['cause1'] = v['na_per'].apply(lambda x: "变量缺失值占比很高(%.2f"% (x*100) +"%)" if x >= 0.8 else "变量有较高缺失值(%.2f"% (x*100) +"%)"  if x >= 0.4 else "变量有一定缺失值(%.2f"% (x*100) +"%)" if x > 0 else "变量没有缺失值")
    cont_features = df.columns[(df.dtypes == 'int64') | (df.dtypes == 'float64')]
    v['std'] = pd.DataFrame(df.apply(lambda x: x.std() if x.name in cont_features else np.exp(1)-1,axis = 0))
    v['score2'] = v['std'].apply(lambda x: np.log(x+1) if x <=10 else np.log(10+1))
    v['cause2'] = v['std'].apply(lambda x: "取值波动很小(%.2f"% x + ")" if x < 3 else "取值波动较小(%.2f"% x + ")"  if x < 10 else "取值有一定波动(%.2f"% x + ")"  if x < 100 else "取值波动较大(%.2f" % x + ")"  )
    if label_colname == '':
        v['score'] = 0.8*v['score1'] + 0.2*v['score2'] 
        v['cause']  =  '1) '+v['cause1'] + '; ' + ' 2)'+v['cause2'] 
        lo_1 = sum(v['std']<=0.1)/len(v)
        lo_2 = sum(v['na_per']>=0.8)/len(v)
        if lo_1 > 0.7 or lo_2 > 0.7:
            print('warning:数据质量不太好，请注意，70%以上字段空缺值严重')
        return v.sort_values(axis = 0,by = 'score',ascending = False)[['na_per','std','score','cause']]

    else:
        type_features = df.columns[df.dtypes == 'object']
        df[type_features] = df[type_features].fillna("missing")
        df = pd.DataFrame(df.apply(lambda x: sklearn.preprocessing.LabelEncoder().fit_transform(x) if x.name in type_features else x, axis = 0))    
        v['corr'] = df.apply(lambda x: x.corr(df[label_colname]) if x.std() != 0 else 0,axis = 0)
        v['cause3'] = v['corr'].apply(lambda x: "与目标变量相关性很高(%.2f"% x +")" if abs(x) >= 0.8 else "与目标变量相关性较高(%.2f"% x +")"  if abs(x) >= 0.5 else "与目标变量有一定相关性(%.2f"% x +")" if abs(x) > 0.2 else "与目标变量相关性很低(%.2f"%x + ")")
        v['score'] = 0.3*v['score1'] + 0.1*v['score2'] + 0.1*abs(v['corr'])     
        v['cause']  =  '1) '+v['cause1'] + '; ' + '2) '+v['cause2'] + '; ' + '3) '+v['cause3'] + '; '   
        lo_1 = sum(v['std']<=0.1)/len(v)
        lo_2 = sum(v['na_per']>=0.8)/len(v)
        if lo_1 > 0.7 or lo_2 > 0.7 :
            print('warning:数据质量不太好，请注意，70%以上字段空缺值严重')
        return v.sort_values(axis = 0,by = 'score',ascending = False)[['na_per','std','score','cause']]

def data_clean(df):
    import pandas as pd
    import numpy as np
    df = df.apply(lambda x: x.replace(' ', np.NaN))  
    def f(x):
        x = x.fillna(x.mean())
        return x    
    def g(x):
        b=sum(x.isnull())/len(x)
        if b<=0.2:
            x = x.fillna(x.mode()[0])
        if b<=0.8 and b>0.2:
            x = x.fillna("unknown")
        return x
    df=df.drop_duplicates(); 
    df=df.dropna(thresh=0.6*df.columns.size)
    cont_features = df.columns[(df.dtypes == 'int64') | (df.dtypes == 'float64')]
    df1=df[cont_features]            
    d1=df1.apply(lambda x: f(x),axis=0)
    type_featrues = df.columns[df.dtypes == 'object']   
    df2=df[type_featrues]            
    d2=df2.apply(lambda x: g(x),axis=0)
    d=d1.join(d2)
    return d

#---特征选择
def v_selection(df,label_colname):
    import pandas as pd
    import numpy  as np
    import sklearn
    from sklearn.model_selection import train_test_split
    from sklearn import preprocessing
    from sklearn.ensemble import RandomForestClassifier
 
    type_features = df.columns[df.dtypes == 'object']    
    df = pd.DataFrame(df.apply(lambda x: sklearn.preprocessing.LabelEncoder().fit_transform(x) if x.name in type_features else x, axis = 0))    
    X  = df[df.columns[df.columns !=  label_colname]]
    y  = df[label_colname]
    train_x,test_x,train_y,test_y = train_test_split(X,y,test_size = 0.2,random_state = 1)
    model=RandomForestClassifier(n_estimators = 100,oob_score=True, random_state=10) ####当前模型或默认模型值
    model.fit(train_x,train_y)
    f = model.feature_importances_
    v_df = pd.DataFrame(dict(zip(X.columns,f)),index=['v_importance']).T.sort_values(axis = 0,by = 'v_importance',ascending = False)
    v_df = pd.concat([v_df,pd.DataFrame(list(range(v_df.shape[0])),index = v_df.index,columns = ['v_rank'])],axis=1)
#计算分数
    v_df['score4'] = v_df['v_importance'].apply(lambda x: 2**((x-min(v_df['v_importance']))/(max(v_df['v_importance'])-min(v_df['v_importance']))) -1)
    v_df = pd.concat([v_df,pd.DataFrame(v_df[['v_rank','v_importance']].apply(lambda x:"变量分辨能力很强(%.4f"% x[1] +")" if x[0] <= round(df.shape[1]*0.2) else "变量具备分辨能力(%.4f"% x[1] +")"  if x[0] <=round(df.shape[1]*0.5) else "变量分辨能力较弱(%.4f"% x[1] +")" if x[0] <=round(df.shape[1]*0.8) else "变量基本没有分辨能力(%.4f"%x[1] + ")",axis = 1),columns = ['cause4'])],axis=1)
    return v_df

    

def model_selection_v():
    import pandas as pd
    import numpy  as np
    #获取路径
    import os
    print('输入数据文件名:（格式如:data.csv  不需引号）')
    data_name = input()
    print('输入数据文件路径:（格式如:c:/data  不需引号）')
    path = input()
    os.chdir(path)
    print('加载数据中。。。。。。')
    print(" ")
    data = pd.read_csv(data_name,encoding = 'gbk',engine = 'python')
    print('输入目标变量名（格式如：宽带办理类型 不需引号），无目标变量直接回车跳过：')
    label_colname = input()
    print('输入标识变量名,用英文逗号隔开（格式如：ID,序号 不需引号）：')
    normal_colname = input()
    normal_colname = normal_colname.split(',')
    print('开始数据质量分析...')
#数据质量分析    
    ana_cont(data)
    ana_type(data) 
    print('-----------第一部分---------')
    print('数据质量分析已完成')
    print('数值型变量结果请见:con_result.csv')
    print('分类型变量结果请见:type_result.csv')
    print('----------------------------')
    print(" ")
#指标评价（初步筛选）
    print("-----------第二部分-----------")         
    v = v_judge(data,label_colname) 
    print('指标初步评价已完成')
    print('----------------------------')
    print(" ")
    del_v = v.index[(v['na_per'] >= 0.8) | (v['std'] <= 0.1)]
    sf = [x for x in v.index if (x not in del_v) | (x == label_colname)]
#筛选后的数据清洗
    d_clean = data_clean(data[sf])
#    normal_data = d_clean_t[normal_colname]
#    d_clean = d_clean_t.drop(normal_colname,axis=1)
    d_clean.to_csv("d_clean.csv",encoding='utf_8_sig')      
    if label_colname == '':
#计算总分
        v_df = pd.concat([pd.DataFrame(np.zeros(d_clean.shape[1]-len(normal_colname)),index = d_clean.drop(normal_colname,1).columns,columns =['s']),v.drop(normal_colname)],axis = 1)            
        v_df['t_s'] = v_df['s'] + v_df['score']  
        v_df = v_df.sort_values(by = 't_s',ascending = False)[['t_s','cause']]
    else:
#特征选择
        v_df = v_selection(d_clean, label_colname)
#计算总分并排名
        v_df = pd.DataFrame(pd.concat([v_df.drop(normal_colname)[['score4','cause4']],v.drop(normal_colname + [label_colname])[['score','cause']]],axis = 1))       
        v_df['t_s'] =  v_df['score'] + 0.5*v_df['score4']  
        v_df['cause4'] = v_df['cause4'].fillna('初步筛选掉此变量')
        v_df['cause'] = v_df['cause'] + '; ' + '4) ' + v_df['cause4']
        v_df = v_df.sort_values(by = 't_s',ascending = False)[['t_s','cause']]
#总结（分数映射/添加标记）
    v_df['total_s'] = 100*((v_df['t_s']- min(v_df['t_s']))/(max(v_df['t_s'])- min(v_df['t_s'])))*0.95    
    v_df['total_s'] = v_df['total_s'].fillna(0)
    v_df['row_rank'] = list(range(v_df.shape[0]))
    v_df['mark'] = v_df[['total_s','row_rank']].apply(lambda x:"√" if x[0] >= 60  else "X" if x[0] == 0 else "*",axis = 1)
    w = pd.DataFrame(['warning: "√"表示质量较好变量,"*"表示质量一般变量,"X"表示建议删除变量'],columns = ['mark'])
    w_df = w.append(v_df)
    w_df[['mark','total_s','cause']].to_csv("v_selection.csv", encoding='utf_8_sig')
    print("-----------第三部分-----------")
    print('指标筛选已完成')
    print('结果可见:v_selection.csv')  
    print('----------------------------')
    print(" ") 
    d_clean_del =  d_clean[v_df[v_df['mark'] == '√'].index]
    d_clean_del = pd.concat([d_clean_del,d_clean[normal_colname]],axis=1)
    d_clean_del.to_csv("d_clean_del.csv", encoding='utf_8_sig')
#整理输出结果      
    return print('清洗完成数据请见:d_clean.csv','清洗完成且变量筛选后的数据请见:d_clean_del.csv',end = '\n')

if __name__ == "__main__":
    model_selection_v()
